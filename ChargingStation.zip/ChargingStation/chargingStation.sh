java -cp target/ChargingStation-1.0-SNAPSHOT.jar:lib/sdk-v0.10-alpha.jar wpwhack.Program
